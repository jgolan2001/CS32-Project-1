//
//  History.cpp
//  Project 1 CS32
//
//  Created by Jordan Golan on 4/1/21.
//

#include <iostream>
#include <cctype>
#include <string>
#include "History.h"

using namespace std;

History::History(int nRows, int nCols)
{
    m_Rows = nRows;
    m_Cols = nCols;
    
    for (int i = 0; i < m_Rows; i++)
    {
        for (int j = 0; j < m_Cols; j++)
        {
            m_city[i][j] = '.';
        }
    }
}

bool History::record(int r, int c)
{
    if ((r > 0 && r <= MAXROWS) && (c > 0 && c <= MAXCOLS))
    {
        if (m_city[r-1][c-1] >= 'A' && m_city[r-1][c-1] < 'Z')
        {
            m_city[r-1][c-1] += 1;
        }
        else if (m_city[r-1][c-1] == 'Z')
        {
            m_city[r-1][c-1] = 'Z';
        }
        else if (m_city[r-1][c-1] == '.')
        {
            m_city[r-1][c-1] = 'A';
        }
        return true;
    }
    else
        return false;
}


void History::display() const
{
    clearScreen();
    for (int i = 0; i < m_Rows; i++)
    {
        for (int j = 0; j < m_Cols; j++)
        {
            cout << m_city[i][j];
        }
        cout << endl;
    }
    cout << endl;
}
