//
//  Game.h
//  Project 1 CS32
//
//  Created by Jordan Golan on 4/1/21.
//

#ifndef Game_h
#define Game_h

#include <stdio.h>

class City;

class Game
{
  public:
        // Constructor/destructor
    Game(int rows, int cols, int nFlatulans);
    ~Game();

        // Mutators
    void play();

  private:
    City* m_city;
};

#endif /* Game_h */
